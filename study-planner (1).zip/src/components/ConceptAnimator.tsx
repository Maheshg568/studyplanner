import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import RequireApiKey from './RequireApiKey';
import { fileToBase64 } from '../utils/fileUtils';
import { Video, Loader2, Upload, PlayCircle } from 'lucide-react';

export default function ConceptAnimator() {
  const [prompt, setPrompt] = useState('A 3D animation showing how a plant cell divides, educational style');
  const [file, setFile] = useState<File | null>(null);
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [videoUrl, setVideoUrl] = useState('');

  const handleGenerate = async () => {
    if (!prompt && !file) {
      setError('Please provide a prompt or an image.');
      return;
    }

    setLoading(true);
    setError('');
    setVideoUrl('');
    setStatus('Initializing video generation...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY });
      
      let imagePayload = undefined;
      if (file) {
        const base64Data = await fileToBase64(file);
        imagePayload = {
          imageBytes: base64Data,
          mimeType: file.type,
        };
      }

      setStatus('Submitting request to Veo...');
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt || undefined,
        image: imagePayload,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio
        }
      });

      setStatus('Generating video... This may take a few minutes.');
      
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
        setStatus('Still generating... Please wait.');
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      
      if (downloadLink) {
        setStatus('Fetching generated video...');
        const response = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': process.env.API_KEY || process.env.GEMINI_API_KEY || '',
          },
        });
        
        if (response.ok) {
          const blob = await response.blob();
          setVideoUrl(URL.createObjectURL(blob));
          setStatus('');
        } else {
          throw new Error('Failed to fetch the video file.');
        }
      } else {
        throw new Error('No video URI returned in the response.');
      }

    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred during video generation.');
      setStatus('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <RequireApiKey>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Concept Animator</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Generate educational videos or animate your study diagrams using Veo 3.
          </p>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={3}
                placeholder="Describe the animation you want to generate..."
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Starting Image (Optional)</label>
                <div className="border border-gray-300 dark:border-gray-600 rounded-lg p-2 flex items-center bg-white dark:bg-gray-700">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                    className="hidden"
                    id="video-image-upload"
                  />
                  <label htmlFor="video-image-upload" className="cursor-pointer flex items-center w-full">
                    <div className="bg-gray-100 dark:bg-gray-600 p-2 rounded mr-3">
                      <Upload className="w-4 h-4 text-gray-500 dark:text-gray-300" />
                    </div>
                    <span className="text-sm text-gray-600 dark:text-gray-300 truncate">
                      {file ? file.name : 'Choose an image to animate...'}
                    </span>
                  </label>
                  {file && (
                    <button 
                      onClick={() => setFile(null)}
                      className="ml-auto text-xs text-red-500 hover:underline px-2"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Aspect Ratio</label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="16:9">16:9 (Landscape)</option>
                  <option value="9:16">9:16 (Portrait)</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={loading || (!prompt && !file)}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed text-white font-medium rounded-lg flex items-center justify-center transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Video className="w-5 h-5 mr-2" />
                  Generate Video
                </>
              )}
            </button>

            {status && (
              <div className="p-4 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-lg text-sm flex items-center justify-center">
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {status}
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg text-sm">
                {error}
              </div>
            )}
          </div>
        </div>

        {videoUrl && (
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
              <PlayCircle className="w-5 h-5 mr-2 text-blue-500" />
              Generated Animation
            </h3>
            <div className="flex justify-center bg-black rounded-lg overflow-hidden">
              <video 
                src={videoUrl} 
                controls 
                autoPlay 
                loop 
                className="max-w-full h-auto max-h-[600px]"
              />
            </div>
          </div>
        )}
      </div>
    </RequireApiKey>
  );
}
