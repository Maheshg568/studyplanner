import React, { useState, useEffect } from 'react';

export default function RequireApiKey({ children }: { children: React.ReactNode }) {
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      // @ts-ignore
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        // @ts-ignore
        const keySelected = await window.aistudio.hasSelectedApiKey();
        setHasKey(keySelected);
      } else {
        // Fallback if not in AI Studio environment
        setHasKey(true);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    // @ts-ignore
    if (window.aistudio && window.aistudio.openSelectKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
      setHasKey(true); // Assume success to avoid race condition
    }
  };

  if (!hasKey) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 text-center">
        <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">API Key Required</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-md">
          This feature uses advanced models (Veo or Imagen) which require a paid Gemini API key from a Google Cloud project.
          <br /><br />
          <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="text-blue-500 hover:underline">
            Learn more about billing
          </a>
        </p>
        <button 
          onClick={handleSelectKey} 
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Select API Key
        </button>
      </div>
    );
  }

  return <>{children}</>;
}
