import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Send, Mic, MicOff, Search, MapPin, Bot, User, Loader2 } from 'lucide-react';

interface Message {
  role: 'user' | 'model';
  text: string;
  urls?: { uri: string; title: string }[];
}

export default function AITutor() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Hello! I am your AI Study Tutor. How can I help you today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  
  const [useSearch, setUseSearch] = useState(false);
  const [useMaps, setUseMaps] = useState(false);
  
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [liveStatus, setLiveStatus] = useState('');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      let modelName = 'gemini-3.1-pro-preview';
      let tools: any[] = [];
      let toolConfig: any = undefined;

      if (useSearch) {
        modelName = 'gemini-3-flash-preview';
        tools.push({ googleSearch: {} });
      } else if (useMaps) {
        modelName = 'gemini-3-flash-preview';
        tools.push({ googleMaps: {} });
      }

      // Convert history to format expected by generateContent if we want multi-turn
      // For simplicity in this demo, we'll send the full history as contents
      const contents = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      contents.push({ role: 'user', parts: [{ text: userMsg }] });

      const response = await ai.models.generateContent({
        model: modelName,
        contents: contents,
        config: {
          tools: tools.length > 0 ? tools : undefined,
          toolConfig: tools.length > 0 ? { includeServerSideToolInvocations: true } : undefined,
          systemInstruction: "You are a helpful, encouraging, and highly knowledgeable AI Study Tutor. Help the student understand concepts, plan their studies, and stay motivated."
        }
      });

      let urls: { uri: string; title: string }[] = [];
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        chunks.forEach((chunk: any) => {
          if (chunk.web?.uri) {
            urls.push({ uri: chunk.web.uri, title: chunk.web.title });
          }
          if (chunk.maps?.uri) {
            urls.push({ uri: chunk.maps.uri, title: chunk.maps.title || 'Google Maps Location' });
          }
        });
      }

      setMessages(prev => [...prev, { 
        role: 'model', 
        text: response.text || 'No response.',
        urls: urls.length > 0 ? urls : undefined
      }]);

    } catch (error: any) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: `Error: ${error.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  // --- Live API (Voice) Implementation ---
  const toggleLiveAudio = async () => {
    if (isLiveActive) {
      stopLiveAudio();
      return;
    }

    try {
      setLiveStatus('Connecting...');
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: {
        sampleRate: 16000,
        channelCount: 1,
        echoCancellation: true,
      } });
      streamRef.current = stream;

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;

      const sessionPromise = ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-12-2025",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: "You are a helpful AI Study Tutor. Keep your responses concise and conversational.",
        },
        callbacks: {
          onopen: () => {
            setLiveStatus('Connected. Speak now!');
            setIsLiveActive(true);
            
            // Setup microphone capture
            const source = audioCtx.createMediaStreamSource(stream);
            const processor = audioCtx.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              // Convert Float32Array to Int16Array
              const pcm16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                let s = Math.max(-1, Math.min(1, inputData[i]));
                pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
              }
              
              // Base64 encode
              const buffer = new ArrayBuffer(pcm16.length * 2);
              const view = new DataView(buffer);
              for (let i = 0; i < pcm16.length; i++) {
                view.setInt16(i * 2, pcm16[i], true); // true for little-endian
              }
              
              let binary = '';
              const bytes = new Uint8Array(buffer);
              for (let i = 0; i < bytes.byteLength; i++) {
                binary += String.fromCharCode(bytes[i]);
              }
              const base64Data = btoa(binary);

              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            };

            source.connect(processor);
            processor.connect(audioCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextRef.current) {
              // Decode and play PCM audio
              const binaryString = atob(base64Audio);
              const bytes = new Uint8Array(binaryString.length);
              for (let i = 0; i < binaryString.length; i++) {
                bytes[i] = binaryString.charCodeAt(i);
              }
              
              // Create AudioBuffer from 16kHz PCM16
              const audioBuffer = audioContextRef.current.createBuffer(1, bytes.length / 2, 16000);
              const channelData = audioBuffer.getChannelData(0);
              const dataView = new DataView(bytes.buffer);
              
              for (let i = 0; i < channelData.length; i++) {
                channelData[i] = dataView.getInt16(i * 2, true) / 0x8000;
              }

              const source = audioContextRef.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(audioContextRef.current.destination);
              source.start();
            }
          },
          onclose: () => {
            stopLiveAudio();
          },
          onerror: (err) => {
            console.error("Live API Error:", err);
            setLiveStatus('Error occurred.');
            stopLiveAudio();
          }
        }
      });

      sessionRef.current = sessionPromise;

    } catch (err) {
      console.error(err);
      setLiveStatus('Failed to connect.');
      setIsLiveActive(false);
    }
  };

  const stopLiveAudio = () => {
    setIsLiveActive(false);
    setLiveStatus('');
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (sessionRef.current) {
      sessionRef.current.then((s: any) => s.close());
      sessionRef.current = null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
      
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-800/50">
        <div className="flex items-center">
          <Bot className="w-6 h-6 text-blue-600 dark:text-blue-400 mr-2" />
          <h2 className="text-lg font-bold text-gray-800 dark:text-white">AI Study Tutor</h2>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => { setUseSearch(!useSearch); setUseMaps(false); }}
            className={`flex items-center px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              useSearch ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' : 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            }`}
          >
            <Search className="w-3 h-3 mr-1" /> Search
          </button>
          <button
            onClick={() => { setUseMaps(!useMaps); setUseSearch(false); }}
            className={`flex items-center px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              useMaps ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' : 'bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
            }`}
          >
            <MapPin className="w-3 h-3 mr-1" /> Maps
          </button>
          <button
            onClick={toggleLiveAudio}
            className={`flex items-center px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              isLiveActive ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300 animate-pulse' : 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300'
            }`}
          >
            {isLiveActive ? <MicOff className="w-3 h-3 mr-1" /> : <Mic className="w-3 h-3 mr-1" />}
            {isLiveActive ? 'Stop Voice' : 'Voice Chat'}
          </button>
        </div>
      </div>

      {liveStatus && (
        <div className="bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-4 py-2 text-sm text-center border-b border-purple-100 dark:border-purple-800">
          {liveStatus}
        </div>
      )}

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                msg.role === 'user' ? 'bg-blue-100 text-blue-600 ml-3' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 mr-3'
              }`}>
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              <div className={`p-3 rounded-2xl ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-tl-none'
              }`}>
                <div className="whitespace-pre-wrap">{msg.text}</div>
                
                {msg.urls && msg.urls.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600 space-y-1">
                    <p className="text-xs font-semibold opacity-70 mb-1">Sources:</p>
                    {msg.urls.map((url, i) => (
                      <a key={i} href={url.uri} target="_blank" rel="noreferrer" className="block text-xs text-blue-500 hover:underline truncate">
                        {url.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="flex flex-row max-w-[80%]">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 mr-3 flex items-center justify-center">
                <Bot className="w-5 h-5" />
              </div>
              <div className="p-4 rounded-2xl bg-gray-100 dark:bg-gray-700 rounded-tl-none flex items-center">
                <Loader2 className="w-5 h-5 animate-spin text-gray-500" />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask your tutor anything..."
            disabled={loading || isLiveActive}
            className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-full focus:ring-2 focus:ring-blue-500 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading || isLiveActive}
            className="p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
